#################################################################
# FILE : math_print.py
# WRITER : David Ruppin , ruppin , 322296336
# EXERCISE : intro2cs1 ex1 2023
# DESCRIPTION: Love it <3
#################################################################

def secret_function():
    print("My username is 'ruppin' and I found the string 'hoI03hIyyxcr' in the submission response.")